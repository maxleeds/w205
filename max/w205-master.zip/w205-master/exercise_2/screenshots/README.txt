Screenshots of Application Use
