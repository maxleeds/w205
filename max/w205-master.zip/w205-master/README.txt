UCB W205 Summer 2017 Exercise 1
