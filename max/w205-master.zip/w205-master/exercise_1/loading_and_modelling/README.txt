Loading and Modelling
